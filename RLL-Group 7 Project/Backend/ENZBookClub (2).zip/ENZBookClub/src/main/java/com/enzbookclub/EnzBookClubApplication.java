package com.enzbookclub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnzBookClubApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnzBookClubApplication.class, args);
	}
}

import { AdminServiceService } from 'src/app/service/admin-service.service';
import { Book } from './../../service/book';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})
export class AddbookComponent implements OnInit {
  book =new Book();
  msg='';
  constructor(private _service:AdminServiceService, private _router :Router ) { }

  ngOnInit(): void {
  }
addBook(){
  this._service.addToDb(this.book).subscribe(
    data =>  {console.log("respone recieved");
    alert("Product Added Successfully");

  },
  _error => {console.log("exception occured");
  this.msg="Bad credential, please enter valid Email and Password";}
 )
}
admindashboard(){
  this._router.navigate(['/adminsuccess'])
}
}


import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from 'src/app/service/admin-service.service';

@Component({
  selector: 'app-viewfeedback',
  templateUrl: './viewfeedback.component.html',
  styleUrls: ['./viewfeedback.component.css']
})
export class ViewfeedbackComponent implements OnInit {

   
  constructor(private Service:AdminServiceService, private router:Router) { }
  feedbacks:any

  ngOnInit(): void {

    let resp =this.Service.getbooks();
    resp.subscribe((data)=>this.feedbacks =data);
  }
  admindashboard(){
    this.router.navigate(['/adminsuccess'])
  }
 
}

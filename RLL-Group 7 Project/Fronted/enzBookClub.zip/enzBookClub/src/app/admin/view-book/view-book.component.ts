import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from './../../service/book';
import { AdminServiceService } from 'src/app/service/admin-service.service';


@Component({
  selector: 'app-view-book',
  templateUrl: './view-book.component.html',
  styleUrls: ['./view-book.component.css']
})
export class ViewBookComponent implements OnInit {
 
  constructor(private Service:AdminServiceService, private router:Router) { }
  books:any
public deleteUser(bid:number){
let resp=this.Service.deleteUser(bid);
resp.subscribe((data)=>this.books=data);

}
  ngOnInit(): void {

    let resp =this.Service.getbooks();
    resp.subscribe((data)=>this.books =data);
  }
  admindashboard(){
    this.router.navigate(['/adminsuccess'])
  }
  updateBook(bid: number){
    this.router.navigate(['/updateBook', bid]);
  }
}


import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ViewBookComponent } from './admin/view-book/view-book.component';
import { AddbookComponent } from './admin/addbook/addbook.component';
import { AdminsuccessComponent } from './admin/adminsuccess/adminsuccess.component';
import { AdminComponent } from './admin/admin.component';
import { RegistrationComponent } from './registration/registration.component';
import { HomeComponent } from './home/home.component';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { LoginComponent } from './login/login.component';
import { UpdatebookComponent } from './admin/updatebook/updatebook.component';
import { ShowbooksComponent } from './loginsuccess/showbooks/showbooks.component';
import { UserfeedbackComponent } from './userfeedback/userfeedback.component';
import { UserprofileComponent } from './loginsuccess/userprofile/userprofile.component';
import { ViewfeedbackComponent } from './admin/viewfeedback/viewfeedback.component';
const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'loginsuccess',component:LoginsuccessComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'admin',component:AdminComponent},
  {path:'adminsuccess',component:AdminsuccessComponent},
  {path:'addbook',component:AddbookComponent},
  {path:'view-book',component:ViewBookComponent},
  {path:'updateBook/:bid',component:UpdatebookComponent},
  {path:'getBookById/:bid',component:UpdatebookComponent},
  {path:'showbook',component:ShowbooksComponent},
  {path:'userfeedback',component:UserfeedbackComponent},
  {path:'userprofile',component:UserprofileComponent},
  {path:'viewfeedback',component:ViewfeedbackComponent},
  {path:'',component:HomeComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

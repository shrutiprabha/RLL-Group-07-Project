import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Feedback } from '../service/feedback';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-userfeedback',
  templateUrl: './userfeedback.component.html',
  styleUrls: ['./userfeedback.component.css']
})
export class UserfeedbackComponent implements OnInit {

  feedback =new Feedback();
  msg='';
  constructor(private _service:UserService, private _router :Router ) { }

  ngOnInit(): void {
  }
addFeedback(){
  this._service.addToDb(this.feedback).subscribe(
    data =>  {console.log("respone recieved");
    alert("Feedback Added Successfully");

  },
  _error => {console.log("exception occured");
  this.msg="Bad credential, please enter valid Email and Password";}
 )
}
userdashboard(){
  this._router.navigate(['/loginsuccess'])
}
}

